# -*- coding: utf-8 -*-
"""
Created on Sat Oct  5 14:52:01 2019

@author: ASSingla
"""

import pandas as pd
import numpy as np
import os
os.chdir(r'D:\Abhishek Singla\3. Adhoc\Housing')
#%%
data=pd.read_csv('housing_train.csv',parse_dates=['Date'])
test=pd.read_csv('housing_test.csv',parse_dates=['Date'])

data.columns
data.dtypes
data.isnull().sum()
data.nunique()

data=data[data['Postcode'].notnull()]

train=data[:1000000]
val=data[1000000:]

text_columns=['AddressLine1', 'AddressLine2', 'Street', 'Locality']
cat_cols1=['Town', 'Taluka', 'District','Postcode']
cat_cols2=['Property Type', 'OldvNew', 'Duration',  'Price Category',]

temp1=train.groupby(cat_cols1,as_index=False).agg({'Price':'mean'})
temp1=temp1.rename(columns={'Price':'avgPrice_cat_cols1'})
temp2=train.groupby(cat_cols2,as_index=False).agg({'Price':'median'})
temp2=temp2.rename(columns={'Price':'avgPrice_cat_cols2'})

#%%
def transform_data(df):
    
    df['DOM']=df['Date'].dt.day
    df['Month']=df['Date'].dt.month
    df['Year']=df['Date'].dt.year
    
    for col in text_columns:
        df[col]=df[col].fillna("")
    
    df['address_str1']=df['AddressLine1'].astype(str)+" "+df['AddressLine2'].astype(str)+" "+df['Street'].astype(str)+" "+df['Locality'].astype(str)  
    df['address_str2']=df['Town'].astype(str)+" "+df['Taluka'].astype(str)+" "+df['District'].astype(str)
    
    df=pd.merge(df,temp1,on=cat_cols1,how='left')   
    df=pd.merge(df,temp2,on=cat_cols2,how='left')
        
    return df

train=transform_data(train)
val=transform_data(val)
test=transform_data(test)

#%%
from sklearn.feature_extraction.text import TfidfVectorizer
vect1 = TfidfVectorizer(ngram_range=(1, 3), max_df=0.5, min_df=100,max_features=500)
vect1.fit(train['address_str1'])
vect2 = TfidfVectorizer(ngram_range=(1, 3), max_df=0.5, min_df=100,max_features=200)
vect2.fit(train['address_str2'])

train.columns
def featurize(df):
    
    dummy1=pd.get_dummies(df[cat_cols2]).reset_index()
    dummy2=pd.DataFrame(vect1.transform(df['address_str1']).todense()).reset_index()
    dummy3=pd.DataFrame(vect1.transform(df['address_str1']).todense()).reset_index()
    dummy4=df[['DOM', 'Month', 'Year','avgPrice_cat_cols1','avgPrice_cat_cols2']].reset_index()
    
    out_df=pd.concat([dummy1,dummy2,dummy3,dummy4],axis=1)
    
    return out_df

train1=train.sample(n=100000).reset_index()
feat_train=featurize(train1)
feat_train=feat_train.fillna(0)
val1=train.sample(n=30000).reset_index()
feat_val=featurize(val1)
feat_val=feat_val.fillna(0)
feat_test=featurize(test)
feat_test=feat_test.fillna(0)

#%%XGBoost
import xgboost
model = xgboost.XGBRegressor(colsample_bytree=0.4,learning_rate=0.1,
                 max_depth=5,min_child_weight=10,
                 n_estimators=10,reg_alpha=1,reg_lambda=1,subsample=0.6,
                 objective='reg:squarederror', booster='gbtree', n_jobs=-1,
                 seed=42) 

model.fit(feat_train.values,train1['Price'].values)

from sklearn.metrics import r2_score
train_out=model.predict(feat_train.values)
r2_score(train1['Price'].values, train_out) 
val_out=model.predict(feat_val.values)
r2_score(val1['Price'].values, val_out) 
test_out=model.predict(feat_test.values)

